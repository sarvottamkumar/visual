import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(inputArray: any[], property:string,choice: string):any[] {
    // if choice is empty return the whole list
    if(!choice)
      return inputArray;
    //create a new array as outputArray
    let outputArray:any[] = [];
    // iterate through the input array to get one by one object
    inputArray.forEach((object:any)=>{
        const val = object[property];
        if(!val)
          outputArray = inputArray; 
        if(val==choice)
          outputArray.push(object)
    })
    return outputArray;
  }
}
