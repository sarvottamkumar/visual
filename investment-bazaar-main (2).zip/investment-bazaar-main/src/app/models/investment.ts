export interface Investment {
    planName:string,
    planId:number;
	entryAge:number;
	type:string; // mutual, ULIP,PPF, FD, RD,
	amount:number;
	purpose:string; // education, retirement, marriage
	risk:string; // high, low
	nominee:string; //father. son, daughter,
	term:number;
}
